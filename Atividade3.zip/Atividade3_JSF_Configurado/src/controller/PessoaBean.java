package controller;

import jakarta.faces.bean.ManagedBean;
import jakarta.faces.bean.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import model.Pessoa;

@ManagedBean
@SessionScoped
public class PessoaBean implements Serializable {
    private Pessoa pessoa = new Pessoa();
    private List<Pessoa> lista = new ArrayList<>();
    private int indexEditando = -1;

    public void adicionar() {
        if (indexEditando == -1) {
            lista.add(new Pessoa(pessoa.getNome(), pessoa.getEmail(), pessoa.getTelefone()));
        } else {
            lista.set(indexEditando, new Pessoa(pessoa.getNome(), pessoa.getEmail(), pessoa.getTelefone()));
            indexEditando = -1;
        }
        pessoa = new Pessoa();
    }

    public void editar(int index) {
        this.pessoa = lista.get(index);
        this.indexEditando = index;
    }

    public void excluir(int index) {
        lista.remove(index);
    }

    public Pessoa getPessoa() { return pessoa; }
    public void setPessoa(Pessoa pessoa) { this.pessoa = pessoa; }
    public List<Pessoa> getLista() { return lista; }
    public void setLista(List<Pessoa> lista) { this.lista = lista; }
}
